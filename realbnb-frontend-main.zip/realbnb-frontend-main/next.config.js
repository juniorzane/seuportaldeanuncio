module.exports = {
  images: {
    domains: ["res.cloudinary.com", "via.placeholder.com"],
  },
};
